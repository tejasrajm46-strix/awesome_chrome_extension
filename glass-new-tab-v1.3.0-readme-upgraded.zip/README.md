<p align="center">
  <img src="assets/readme/hero.svg" width="100%" alt="Glass New Tab — a calm, customizable browser start page with a bookmark library built around pages and boards">
</p>

<p align="center">
  <a href="releases/glass-new-tab-v1.3.0.zip"><img src="https://img.shields.io/badge/Download-v1.3.0-E0483C?style=for-the-badge&logo=googlechrome&logoColor=white" alt="Download Glass New Tab v1.3.0"></a>
  <img src="https://img.shields.io/badge/Chrome%20%2F%20Edge-Manifest%20V3-BA362A?style=for-the-badge" alt="Chrome and Edge Manifest V3">
  <img src="https://img.shields.io/badge/Privacy-local%20by%20default-E0483C?style=for-the-badge" alt="Local by default">
  <img src="https://img.shields.io/badge/License-MIT-822319?style=for-the-badge" alt="MIT license">
</p>

<p align="center">
  <strong>Your next tab. Your space. Your library.</strong><br>
  Turn every new tab into a personal dashboard — with a bookmark library that stays organised as it grows.
</p>

<p align="center">
  <a href="#-get-started">Get started</a> ·
  <a href="#-what-makes-it-different">Features</a> ·
  <a href="#-take-a-look">Screenshots</a> ·
  <a href="#-keyboard-shortcuts">Shortcuts</a> ·
  <a href="#-privacy--permissions">Privacy</a>
</p>

---

<p align="center">
  <img src="docs/dashboard.jpg" width="100%" alt="Glass New Tab dashboard with a custom dark wallpaper, clock, greeting, search, quote and a scrolling bookmark library">
</p>

<p align="center"><em>A workspace that feels like yours — not another endless pile of bookmarks.</em></p>

## ✦ What makes it different

Most new-tab pages give you a search box and a wall of links. **Glass New Tab gives your bookmarks structure.**

- **Pages** separate contexts like Work, Personal and Reading.
- **Boards** organise each page into focused collections.
- **A contained, scrollable library** keeps the dashboard tidy — even when your collection gets big.
- **A flexible canvas** lets you move and resize widgets to fit your screen.
- **Local-first by design** keeps your workspace in your browser profile, without an account or analytics.

The result: a new tab that looks like your space and works like a library.

<p align="center">
  <img src="assets/readme/how-it-works.svg" width="100%" alt="Glass New Tab information architecture: pages contain boards, boards contain bookmarks, and workspace data stays in the local browser profile">
</p>

## ✨ What you can do

<table>
  <tr>
    <td width="50%" valign="top">
      <h3>📚 A bookmark library that scales</h3>
      Pages, boards, favourites, recently visited items, drag-and-drop organisation, quick-save, and a 30-day Trash with restore.
    </td>
    <td width="50%" valign="top">
      <h3>⌕ Find the right link</h3>
      Search titles, URLs, descriptions and <code>#tags</code>. Filter by page, board, favourites or recently visited; sort by name, date, usage or your own order.
    </td>
  </tr>
  <tr>
    <td width="50%" valign="top">
      <h3>🎨 Make it yours</h3>
      Light, Glass and Dark themes, eight accent colours, custom image or video wallpapers, and widgets you can move and resize.
    </td>
    <td width="50%" valign="top">
      <h3>⚡ A faster daily flow</h3>
      Pick your search engine, use keyboard shortcuts, save the current page in a keystroke, and import or export your library when you need to move it.
    </td>
  </tr>
  <tr>
    <td width="50%" valign="top">
      <h3>🧩 Layout that adapts</h3>
      Choose grid or list layouts, adjust card size and shape, tune columns and glass effects, and save arrangements for different screen sizes.
    </td>
    <td width="50%" valign="top">
      <h3>🔒 Yours by default</h3>
      No account, sync server, analytics or telemetry. Your workspace stays in your browser profile; only search suggestions and bookmark favicons need network access.
    </td>
  </tr>
</table>

### Your library, your rules

<p align="center">
  <img src="assets/readme/section-01-bookmarks.svg" width="100%" alt="Bookmark pages, boards, favourites, drag and drop, Trash, undo and import or export">
</p>

| Tool | How it helps |
|---|---|
| **Pages + boards** | Keep separate contexts organised without mixing their contents. |
| **Quick-save** | Save the current page with `Ctrl`/`⌘` + `Shift` + `Y`, the toolbar button, or the right-click menu. |
| **Favourites + Trash** | Star important links, restore deleted items for up to 30 days, and undo or redo changes. |
| **Import + export** | Back up as JSON, or import/export Netscape HTML and CSV. Import Chrome bookmarks when you choose to grant the optional permission. |
| **Privacy mode** | Blur bookmark titles until you hover over them. |
| **Flexible display** | Switch between grid, vertical list and compact list; tune columns, card size, shape, transparency and blur. |

### Search without losing your place

<p align="center">
  <img src="assets/readme/section-02-find.svg" width="100%" alt="Search bookmark titles, URLs, descriptions and tags with filters and exact matching">
</p>

Search across **titles, URLs, descriptions and `#tags`**, then narrow results by location. The **Exact** toggle helps when broad matching returns too much.

Supported search engines include Google, Bing, DuckDuckGo, Brave, Yahoo and Ecosia — or use a custom URL template with `%s`.

### A dashboard that fits you

<p align="center">
  <img src="assets/readme/section-03-yours.svg" width="100%" alt="Personalise themes, accent colours, backgrounds, widgets and layout">
</p>

Choose a theme, pick an accent, set your own image or looping video as the background, then open **Customize** to drag and resize widgets. The clock, search, quote and bookmark keepers can each be shown or hidden.

### Private by default — not by promise alone

<p align="center">
  <img src="assets/readme/section-04-private.svg" width="100%" alt="Privacy-focused design: local browser storage, no account and no analytics">
</p>

- **No account or sign-in.**
- **No analytics, telemetry or remote code.**
- Bookmark data, pages, boards, layout and preferences live in your browser profile's `localStorage`.
- Uploaded video wallpapers are stored in `IndexedDB`.
- Network requests are limited to search suggestions for the selected engine and favicon images for your saved bookmarks.
- The `bookmarks` permission is optional and requested only when you choose **Import Chrome**.

> **Good to know:** Glass New Tab does not currently sync between browser profiles. Use **⋯ → Export backup** to keep a copy or move your library.

## 🚀 Get started

### Option A — Install from the release ZIP

No terminal. No build step.

1. Download **[Glass New Tab v1.3.0](releases/glass-new-tab-v1.3.0.zip)**.
2. Unzip the download. Open the extracted `glass-new-tab` folder.
3. In Chrome, visit `chrome://extensions`. In Edge, visit `edge://extensions`.
4. Enable **Developer mode**.
5. Click **Load unpacked** and select the `glass-new-tab` folder — the one containing `manifest.json`.
6. Open a new tab. You're in.

<p align="center">
  <img src="assets/readme/section-05-install.svg" width="100%" alt="Install Glass New Tab by extracting the ZIP and loading the folder through the browser's extensions page">
</p>

### Option B — Clone the repository

```bash
git clone https://github.com/tejasrajm46-strix/awesome_chrome_extension.git
```

Then load the cloned repository folder through **Load unpacked**. The repository root contains the extension directly; there is no `npm install`, bundler or build command.

**After changing code:** click the reload icon on the extension card, then refresh the new tab.

## 👀 Take a look

<p align="center">
  <img src="docs/first-run.jpg" width="100%" alt="First run of Glass New Tab with a starter library and built-in boards">
</p>
<p align="center"><em>Ready to explore from the first launch.</em></p>

<p align="center">
  <img src="docs/bookmark-panel.jpg" width="82%" alt="Bookmark panel with page and board controls, search, filters, sorting and card layout controls">
</p>
<p align="center"><em>Keep the collection organised without letting it take over the page.</em></p>

<p align="center">
  <img src="docs/custom-background.jpg" width="100%" alt="Glass New Tab with a custom wallpaper and personally arranged dashboard widgets">
</p>
<p align="center"><em>Your background. Your layout. Your rhythm.</em></p>

## ⌨️ Keyboard shortcuts

| Shortcut | Action |
|---|---|
| `Ctrl` / `⌘` + `K` | Focus bookmark search |
| `Ctrl` / `⌘` + `B` | Jump to Favourites |
| `Ctrl` / `⌘` + `Z` | Undo |
| `Ctrl` / `⌘` + `Shift` + `Z` | Redo |
| `Ctrl` / `⌘` + `Shift` + `Y` | Quick-save the current page |
| `←` / `→` / `Home` / `End` | Move through page and board pills |
| Arrow keys in **Customize** | Resize the selected widget; hold `Shift` to move it |
| `Esc` | Close a modal or leave Customize mode |

## 🛡️ Privacy & permissions

| Permission | Why it is used |
|---|---|
| `storage` | Extension storage support for the local workspace. |
| `tabs` | Open saved bookmarks and quick-save the current tab. |
| `contextMenus` | Add **Save to Glass New Tab** to the right-click menu. |
| `bookmarks` *(optional)* | Read Chrome bookmarks only when you choose **Import Chrome**. |
| Search/favicon host access | Fetch suggestions from supported search providers and favicons for saved links. |

Glass New Tab is built with **Manifest V3**, plain JavaScript and CSS. It has no third-party runtime dependencies or build pipeline.

## 🧭 Project structure

```text
awesome_chrome_extension/
├── manifest.json          # Extension metadata and new-tab override
├── newtab.html            # Dashboard entry point
├── css/style.css          # Themes, cards, glass effects and responsive layout
├── js/
│   ├── app.js             # Startup, onboarding and daily quote
│   ├── workspace.js       # Pages, boards, bookmarks, search and import/export
│   ├── layout.js           # Widget placement and resizing
│   ├── background.js       # Image/video wallpaper handling
│   ├── search.js           # Search engines and suggestions
│   ├── settings.js         # Appearance and preferences
│   ├── storage.js          # Local storage helpers
│   ├── bookmarks.js        # Starter bookmark data
│   ├── clock.js            # Clock and greeting
│   └── service-worker.js   # Toolbar and context-menu actions
├── assets/                 # Extension icons, brand files and README artwork
├── docs/                   # Screenshots and brand references
└── releases/               # Packaged release ZIP
```

## ⚖️ Current limitations

A few things to know before you make it your daily driver:

- **No cross-profile sync.** Export/import is the way to move a library.
- **Dense grids can truncate titles.** Use 2–3 columns or switch to a list layout when space is tight.
- **Layouts are saved by screen-size class.** Moving between size classes uses that class's saved arrangement.
- **Keyboard navigation is still evolving.** Cards can be reached with `Tab`, but arrow-key traversal inside the bookmark grid is not available yet.
- **Incognito access must be enabled by you** in the browser's extension settings.

## 🤝 Contributing

Found a bug or have an idea? Issues and pull requests are welcome.

1. Make your change in `js/` or `css/`.
2. Load the extension unpacked in Chrome or Edge.
3. Reload the extension and refresh the new tab.
4. For behaviour changes, include the browser used and a screenshot or short description of what you tested.

No build step required.

## 📄 License

Released under the **MIT License**. The Inter typeface is licensed under the SIL Open Font License.

---

<p align="center">
  <img src="assets/brand/png/logo-mono-red-512.png" width="42" alt="Glass New Tab logo">
  <br>
  <strong>Glass New Tab</strong><br>
  <em>A calmer start. A smarter library.</em>
</p>
